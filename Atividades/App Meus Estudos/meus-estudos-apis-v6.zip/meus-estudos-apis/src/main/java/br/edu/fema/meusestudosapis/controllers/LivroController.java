package br.edu.fema.meusestudosapis.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import br.edu.fema.meusestudosapis.business.LivroBO;
import br.edu.fema.meusestudosapis.models.LivroVO;
import br.edu.fema.meusestudosapis.models.metrics.LivroMetrica1;
import br.edu.fema.meusestudosapis.models.metrics.LivroMetrica2;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@CrossOrigin
@Controller
@RequestMapping("/api/livros")
public class LivroController {

    @Autowired
    private LivroBO livroBO;

    @ApiOperation("Recupera todos os livros")
    @RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @ApiResponses({ @ApiResponse(code = 200, message = "Todos os livros"),
            @ApiResponse(code = 500, message = "Erro interno"),
            @ApiResponse(code = 404, message = "Livro não encontrado") })
    public ResponseEntity<List<LivroVO>> getLivros() {
        return ResponseEntity.ok(this.livroBO.getLivros()); // ok = 200
    }

    @ApiOperation("Recupera quantidade de livros por categoria")
    @RequestMapping(value = "/quantidadeLivrosPorCategoria", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<List<LivroMetrica1>> getQuantidadeLivrosPorCategoria() {
        return ResponseEntity.ok(this.livroBO.getQuantidadeLivrosPorCategoria());
    }

    @ApiOperation("Recupera quantidade de livros por autor")
    @RequestMapping(value = "/quantidadeLivrosPorAutor", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<List<LivroMetrica2>> getQuantidadeLivrosPorAutor() {
        return ResponseEntity.ok(this.livroBO.getQuantidadeLivrosPorAutor());
    }

    @ApiOperation("Insere um novo livro")
    @RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<LivroVO> insertLivro(@RequestBody LivroVO livro) {
        LivroVO result = this.livroBO.insertLivro(livro);

        return ResponseEntity.status(HttpStatus.CREATED).body(result);
    }

    @ApiOperation("Atualiza um livro pelo {isbn}")
    @RequestMapping(value = "/{isbn}", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<LivroVO> updateLivro(@PathVariable("isbn") String isbn, @RequestBody LivroVO livro) {
        livro.setIsbn(isbn);

        LivroVO result = this.livroBO.updateLivro(livro);

        if (result != null) {
            return ResponseEntity.ok(result);
        }

        return ResponseEntity.notFound().build();
    }

    @ApiOperation("Remove um livro pelo {isbn}")
    @RequestMapping(value = "/{isbn}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<LivroVO> deleteLivro(@PathVariable("isbn") String isbn) {
        LivroVO result = this.livroBO.deleteLivro(isbn);

        if (result != null) {
            return ResponseEntity.ok(result);
        }

        return ResponseEntity.notFound().build();
    }

}
