package br.edu.fema.meusestudosapis.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import br.edu.fema.meusestudosapis.models.LivroVO;
import br.edu.fema.meusestudosapis.models.metrics.LivroMetrica1;
import br.edu.fema.meusestudosapis.models.metrics.LivroMetrica2;

public interface LivroRepository extends PagingAndSortingRepository<LivroVO, String> {

    // ORM

    @Query("SELECT new br.edu.fema.meusestudosapis.models.metrics.LivroMetrica1(l.categoria, COUNT(l)) "
            + "FROM LivroVO l "
            + "GROUP BY l.categoria "
            + "ORDER BY COUNT(l) DESC, l.categoria")
    List<LivroMetrica1> findQuantidadeLivrosPorCategoria();

    @Query("SELECT new br.edu.fema.meusestudosapis.models.metrics.LivroMetrica2(l.autor, COUNT(l)) "
            + "FROM LivroVO l "
            + "GROUP BY l.autor "
            + "ORDER BY COUNT(l) DESC, l.autor")
    List<LivroMetrica2> findQuantidadeLivrosPorAutor();

}
