package br.edu.fema.meusestudosapis.models.metrics;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@AllArgsConstructor
@Data
@Builder
public class LivroMetrica2 {

    private String autor;
    private Long quantidadeLivros;

}
