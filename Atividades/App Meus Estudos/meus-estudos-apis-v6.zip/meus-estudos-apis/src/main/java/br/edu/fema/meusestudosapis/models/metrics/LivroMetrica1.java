package br.edu.fema.meusestudosapis.models.metrics;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@AllArgsConstructor
@Data
@Builder
public class LivroMetrica1 {

    private String categoria;
    private Long quantidadeLivros;

}
