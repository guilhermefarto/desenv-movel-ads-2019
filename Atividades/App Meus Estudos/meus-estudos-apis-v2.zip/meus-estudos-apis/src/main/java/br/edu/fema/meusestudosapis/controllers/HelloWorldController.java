package br.edu.fema.meusestudosapis.controllers;

import java.math.BigDecimal;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/api/hello")
public class HelloWorldController {

	// /api/hello
	
	@RequestMapping(method = RequestMethod.GET, 
		produces = MediaType.TEXT_PLAIN_VALUE)
	@ResponseBody
	public String hello() {
		return "Hello, FEMA";
	}
	
	// /api/hello/ADS/Desenv. Móvel

	@RequestMapping(value = "/{curso}/{disciplina}", 
			method = RequestMethod.GET, 
			produces = MediaType.TEXT_PLAIN_VALUE)
	@ResponseBody
	public String getCursoDisciplina(@PathVariable("curso") String curso,
			                   @PathVariable("disciplina") String disciplina) {
		return "Procurando disciplina " + disciplina + " para o curso " + curso;
	}
	
	// /api/hello/soma/{num1}/{num2}
	
	@RequestMapping(value="/{operacao}/{num1}/{num2}",
			method=RequestMethod.GET,
			produces = MediaType.TEXT_PLAIN_VALUE)
	@ResponseBody
	public String calcularSoma(@PathVariable("operacao") String operacao, 
			                   @PathVariable("num1") BigDecimal num1, 
			                   @PathVariable("num2") BigDecimal num2) {
		if ("soma".equals(operacao)) {
			return String.valueOf(num1.add(num2));
		} else if ("sub".equals(operacao)) {
			return String.valueOf(num1.subtract(num2));
		}
		
		return "*";
	}

}















