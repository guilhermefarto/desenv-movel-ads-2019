package br.edu.fema.meusestudosapis.business;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.stereotype.Service;

import br.edu.fema.meusestudosapis.models.EventoVO;

@Service
public class EventoBO {

	// Generics
	private static Map<String, EventoVO> eventos = new LinkedHashMap<String, EventoVO>();

	// SELECT * FROM EVENTOS;
	public List<EventoVO> getEventos() {
		return new LinkedList<>(eventos.values());
	}
	
	public EventoVO insertEvento(EventoVO evento) {
		evento.setCodigo(UUID.randomUUID().toString());

		// INSERT INTO EVENTOS (CODIGO, DESCRICAO) VALUES (?, ?);
		eventos.put(evento.getCodigo(), evento); // chave , valor

		return evento;
	}
	
	public EventoVO updateEvento(EventoVO evento) {
		if (eventos.containsKey(evento.getCodigo())) {
			eventos.put(evento.getCodigo(), evento);

			return evento;
		}

		return null;
	}

	public EventoVO deleteEvento(String codigo) {
		if (eventos.containsKey(codigo)) {
			EventoVO evento = eventos.get(codigo);

			eventos.remove(codigo);

			return evento;
		}

		return null;
	}
	
	public static void main(String[] args) {
		EventoBO bo = new EventoBO();
		
		System.out.println(bo.getEventos());
		
		EventoVO tdc = EventoVO.builder().tipo("The Dev Conf SP 2019").pago(true).build();
		EventoVO javaOne = EventoVO.builder().tipo("Java One 2019").pago(false).build();
		
		bo.insertEvento(tdc);
		
		System.out.println(bo.getEventos());
		
		bo.insertEvento(javaOne);
		
		System.out.println(bo.getEventos());
		
		// bo.updateEvento(evento);
		
		// bo.deleteEvento(codigo);
		
	}
	
}
