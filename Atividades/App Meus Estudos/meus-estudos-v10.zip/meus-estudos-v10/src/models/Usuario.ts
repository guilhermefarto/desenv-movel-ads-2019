export class Usuario {

    login: string;
    password: string;
    name: string;
    email: string;
}