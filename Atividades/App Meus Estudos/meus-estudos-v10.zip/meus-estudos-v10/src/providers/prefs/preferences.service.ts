import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PreferencesService {

  constructor(
    private storage: Storage
  ) { }

  save(key: string, value: any): Observable<any> {
    return Observable.create((observer: any) => {
      this.storage.set(key, value).then((data) => {
        observer.next(value);
      });
    });
  }

  get(key: string): Observable<any> {
    return Observable.create((observer: any) => {
      this.storage.get(key).then((data) => {
        observer.next(data);
      });
    });
  }

  remove(key: string): Observable<any> {
    return Observable.create((observer: any) => {
      this.storage.remove(key).then((data) => {
        observer.next(data);
      });
    });
  }

  clear(): Observable<any> {
    return Observable.create((observer: any) => {
      this.storage.clear().then(() => {
        observer.next();
      });
    });
  }

  keys(): Observable<Array<string>> {
    return Observable.create((observer: any) => {
      this.storage.keys().then((data) => {
        observer.next(data);
      });
    });
  }

}
