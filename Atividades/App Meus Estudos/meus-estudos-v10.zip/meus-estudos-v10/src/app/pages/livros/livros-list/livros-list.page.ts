import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { NavController } from '@ionic/angular';
import { Chart } from 'chart.js';
import { Livro } from 'src/models/Livro';
import { LivrosService } from 'src/providers/livros/livros.service';

@Component({
  selector: 'app-livros-list',
  templateUrl: './livros-list.page.html',
  styleUrls: ['./livros-list.page.scss'],
})
export class LivrosListPage implements OnInit {

  // npm install chart.js --save

  @ViewChild('barCanvas') barCanvas: ElementRef;
  @ViewChild('barCanvasAutor') barCanvasAutor: ElementRef;

  private barChart: Chart;
  private barChartAutor: Chart;

  livros: Livro[] = [];

  constructor(
    private livrosService: LivrosService,
    private navController: NavController,
  ) { }

  ngOnInit() {
    this.livrosService.quantidadeLivrosPorCategoria()
      .subscribe((data) => {
        console.log('Quantidade de livros por categoria:');
        console.log(data);

        const labels: Array<string> = data.map(item => item.categoria); // ["Romance", "Técnico", ""]
        const values: Array<number> = data.map(item => item.quantidadeLivros); // [20, 10, 3]

        this.barChart = new Chart(this.barCanvas.nativeElement, {
          type: 'bar',
          data: {
            labels: labels,
            datasets: [
              {
                label: '# de livros',
                data: values,
                backgroundColor: [
                  'rgba(255, 99, 132, 0.2)',
                  'rgba(54, 162, 235, 0.2)',
                  'rgba(255, 206, 86, 0.2)',
                ],
                borderColor: [
                  'rgba(255,99,132,1)',
                  'rgba(54, 162, 235, 1)',
                  'rgba(255, 206, 86, 1)',
                ],
                borderWidth: 1
              }
            ]
          },
          options: {
            scales: {
              yAxes: [
                {
                  ticks: {
                    beginAtZero: true
                  }
                }
              ]
            }
          }
        });
      });

    this.livrosService.quantidadeLivrosPorAutor()
      .subscribe((data) => {
        console.log('Quantidade de livros por autor:');
        console.log(data);

        const labels: Array<string> = data.map(item => item.autor);
        const values: Array<number> = data.map(item => item.quantidadeLivros);

        this.barChartAutor = new Chart(this.barCanvasAutor.nativeElement, {
          type: 'pie',
          data: {
            labels: labels,
            datasets: [
              {
                label: '# de livros',
                data: values,
                backgroundColor: [
                  'rgba(255, 99, 132, 0.2)',
                  'rgba(54, 162, 235, 0.2)',
                  'rgba(255, 206, 86, 0.2)',
                ],
                borderColor: [
                  'rgba(255,99,132,1)',
                  'rgba(54, 162, 235, 1)',
                  'rgba(255, 206, 86, 1)',
                ],
                borderWidth: 1
              }
            ]
          },
          options: {
            legend: {
              display: false
            }
          }
        });
      });
  }

  ionViewWillEnter() {
    this.doLoadLivros();
  }

  doLoadLivros() {
    this.livrosService.consultarLivros().subscribe((livros) => {
      this.livros = livros;
    });
  }

  doRemover(isbn: string) {
    this.livrosService.removerLivro(isbn).subscribe((livros) => {
      this.livros = livros;
    });
  }

  doIncluir() {
    this.navController.navigateForward('livros-create');
  }

  doSincronizar() {
    this.livrosService.sincronizarLivros().subscribe((livros) => {
      this.livros = livros;
    });
  }

}
