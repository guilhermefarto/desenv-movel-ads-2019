import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { Livro } from 'src/models/Livro';
import { LivrosService } from 'src/providers/livros/livros.service';

@Component({
  selector: 'app-livros-create',
  templateUrl: './livros-create.page.html',
  styleUrls: ['./livros-create.page.scss'],
})
export class LivrosCreatePage implements OnInit {

  novoLivroForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private navController: NavController,
    private livrosService: LivrosService,
  ) {
    this.novoLivroForm = this.formBuilder.group({
      isbn: ['', Validators.required],
      titulo: ['', Validators.required],
      autor: ['', Validators.required],
      quantidadePaginas: ['', Validators.required],
      categoria: ['', Validators.required],
    });
  }

  ngOnInit() {
  }

  doSalvar() {
    const novoLivro = this.novoLivroForm.getRawValue() as Livro;

    console.log(novoLivro);

    this.livrosService.salvarLivro(novoLivro).subscribe((livros) => {
      this.navController.navigateBack('livros-list');
    });
  }

}
