import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { Evento } from 'src/models/Evento';
import { EventosService } from 'src/providers/eventos/eventos.service';

@Component({
  selector: 'app-eventos-list',
  templateUrl: './eventos-list.page.html',
  styleUrls: ['./eventos-list.page.scss'],
})
export class EventosListPage implements OnInit {

  eventos: Evento[] = [];

  constructor(
    private eventosService: EventosService,
    private navController: NavController,
  ) { }

  ngOnInit() {
  }

  ionViewWillEnter() {
    this.doLoadEventos();
  }

  doLoadEventos() {
    this.eventosService.consultarEventos().subscribe((eventos) => {
      this.eventos = eventos;
    });
  }

  doRemover(codigo: string) {
    this.eventosService.removerEvento(codigo).subscribe((eventos) => {
      this.eventos = eventos;
    });
  }

  doIncluir() {
    this.navController.navigateForward('eventos-create');
  }
}