import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventosCreatePage } from './eventos-create.page';

describe('EventosCreatePage', () => {
  let component: EventosCreatePage;
  let fixture: ComponentFixture<EventosCreatePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EventosCreatePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventosCreatePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
