import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { EventosService } from 'src/providers/eventos/eventos.service';
import { Evento } from 'src/models/Evento';

@Component({
  selector: 'app-eventos-create',
  templateUrl: './eventos-create.page.html',
  styleUrls: ['./eventos-create.page.scss'],
})
export class EventosCreatePage implements OnInit {

  novoEventoForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private navController: NavController,
    private eventosService: EventosService,
  ) {
    this.novoEventoForm = this.formBuilder.group({
      codigo: ['', Validators.required],
      titulo: ['', Validators.required],
      tipo: ['', Validators.required],
      local: ['', Validators.required],
      data: ['', Validators.required],
      pago: ['false'],
    });
  }

  ngOnInit() {
  }

  doSalvar() {
    let novoEvento = this.novoEventoForm.getRawValue() as Evento;

    console.log(novoEvento);

    this.eventosService.salvarEvento(novoEvento).subscribe((eventos) => {
      this.navController.navigateBack('eventos-list');
    });
  }
}