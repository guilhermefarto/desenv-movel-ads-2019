import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Usuario } from 'src/models/Usuario';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor() { }

  validar(usuario: Usuario): Observable<boolean> {

    return Observable.create((observer: any) => {
      if (usuario.password === '123') {
        observer.next(true);
      } else {
        observer.error('Falha na autenticação do usuário.');
      }
    });
  }

}
