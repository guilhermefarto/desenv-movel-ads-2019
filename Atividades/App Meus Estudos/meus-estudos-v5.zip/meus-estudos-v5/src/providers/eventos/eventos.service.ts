import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Evento } from 'src/models/Evento';
import { PreferencesService } from '../prefs/preferences.service';

@Injectable({
  providedIn: 'root'
})
export class EventosService {

  constructor(
    private preferencesService: PreferencesService,
  ) { }

  consultarEventos(): Observable<Evento[]> {
    return Observable.create((observer: any) => {
      this.preferencesService.get('eventos').subscribe((eventos: Evento[]) => {
        observer.next(eventos);
      });
    });
  }

  salvarEvento(novoEvento: Evento): Observable<Evento[]> {
    return Observable.create((observer: any) => {
      this.preferencesService.get('eventos').subscribe((eventos: Evento[]) => {
        if (eventos === undefined || eventos === null) {
          eventos = [];
        }

        let eventoIndex = eventos.findIndex(evento => evento.codigo === novoEvento.codigo);

        if (eventoIndex !== -1) {
          eventos[eventoIndex] = novoEvento;
        } else {
          eventos.push(novoEvento);
        }

        this.preferencesService.save('eventos', eventos).subscribe(() => {
          observer.next(eventos);
        });
      });
    });
  }

  removerEvento(codigo: string): Observable<Evento[]> {
    return Observable.create((observer: any) => {
      this.preferencesService.get('eventos').subscribe((eventos: Evento[]) => {
        if (eventos === undefined || eventos === null) {
          eventos = [];
        }

        eventos = eventos.filter(evento => evento.codigo !== codigo);

        this.preferencesService.save('eventos', eventos).subscribe(() => {
          observer.next(eventos);
        });
      });
    });
  }
}