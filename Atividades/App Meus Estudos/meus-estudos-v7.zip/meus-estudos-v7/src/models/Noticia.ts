export class Noticia {

    titulo: string;
    resumo: string;
    link: string;

}