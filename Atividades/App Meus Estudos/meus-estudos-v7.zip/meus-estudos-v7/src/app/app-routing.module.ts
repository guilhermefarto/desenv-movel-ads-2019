import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'home', loadChildren: './pages/home/home.module#HomePageModule' },
  { path: 'login', loadChildren: './pages/login/login.module#LoginPageModule' },
  { path: 'noticias-list', loadChildren: './pages/noticias/noticias-list/noticias-list.module#NoticiasListPageModule' },
  { path: 'meus-dados', loadChildren: './pages/usuario/meus-dados/meus-dados.module#MeusDadosPageModule' },
  { path: 'eventos-list', loadChildren: './pages/eventos/eventos-list/eventos-list.module#EventosListPageModule' },
  { path: 'eventos-create', loadChildren: './pages/eventos/eventos-create/eventos-create.module#EventosCreatePageModule' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
