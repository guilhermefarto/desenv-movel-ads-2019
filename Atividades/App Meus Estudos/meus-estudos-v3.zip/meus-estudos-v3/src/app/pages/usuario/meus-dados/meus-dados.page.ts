import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-meus-dados',
  templateUrl: './meus-dados.page.html',
  styleUrls: ['./meus-dados.page.scss'],
})
export class MeusDadosPage implements OnInit {

  meusDadosForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private navController: NavController,
  ) {
    this.meusDadosForm = this.formBuilder.group({
      login: ['', Validators.required],
      name: ['', Validators.required],
      email: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  ngOnInit() {
  }

  doSalvar() {
    let userData = this.meusDadosForm.getRawValue() as any;

    console.log(userData);

    this.navController.navigateBack('home');
  }

}
