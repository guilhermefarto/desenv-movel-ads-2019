package br.edu.fema.meusestudosapis;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MeusEstudosApisApplicationTests {

	@Test
	public void contextLoads() {
	}

}
