package br.edu.fema.meusestudosapis.models;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "Evento", description = "Representa uma entidade de evento")
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class EventoVO {

	@ApiModelProperty(value = "Código do evento")
	private String codigo;

	@ApiModelProperty(value = "Título do evento")
	private String titulo;

	@ApiModelProperty(value = "Tipo do evento")
	private String tipo;

	@ApiModelProperty(value = "Local do evento")
	private String local;

	@ApiModelProperty(value = "Data do evento")
	private String data;

	@ApiModelProperty(value = "Categoria do evento (pago ou gratuito)")
	private boolean pago;

}
