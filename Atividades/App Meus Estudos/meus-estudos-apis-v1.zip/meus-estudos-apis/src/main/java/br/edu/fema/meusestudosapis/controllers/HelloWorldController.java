package br.edu.fema.meusestudosapis.controllers;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

// http://localhost:9090/meus-estudos/api/hello
// http://localhost:9090/meus-estudos/api/hello/Guilherme%20Farto

@Controller
@RequestMapping("/api/hello")
public class HelloWorldController {

	@RequestMapping(method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
	@ResponseBody
	public String hello() {
		return "Hello, FEMA";
	}

	@RequestMapping(value = "/{name}", method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
	@ResponseBody
	public String getHelloPath(@PathVariable("name") String name) {
		return "Hello, " + name + "!";
	}

}
