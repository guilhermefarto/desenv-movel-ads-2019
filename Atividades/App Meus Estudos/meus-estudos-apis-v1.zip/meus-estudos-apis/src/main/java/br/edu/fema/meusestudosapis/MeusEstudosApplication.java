package br.edu.fema.meusestudosapis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// https://start.spring.io/

@SpringBootApplication
public class MeusEstudosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeusEstudosApplication.class, args);
	}

}
