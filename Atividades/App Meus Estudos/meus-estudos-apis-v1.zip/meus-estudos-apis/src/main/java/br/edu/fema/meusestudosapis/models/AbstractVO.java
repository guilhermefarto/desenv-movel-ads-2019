package br.edu.fema.meusestudosapis.models;

import java.security.SecureRandom;

public abstract class AbstractVO {

	public static String generateGUID() {
		Long random = 0L;

		try {
			random = SecureRandom.getInstance("SHA1PRNG").nextLong();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return String.valueOf(Math.abs(random));
	}

}
