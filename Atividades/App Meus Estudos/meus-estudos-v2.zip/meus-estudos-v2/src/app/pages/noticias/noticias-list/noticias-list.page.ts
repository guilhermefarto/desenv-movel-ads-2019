import { Component, OnInit } from '@angular/core';
import { NoticiasService } from 'src/providers/noticias/noticias.service';
import { Noticia } from 'src/models/Noticia';

@Component({
  selector: 'app-noticias-list',
  templateUrl: './noticias-list.page.html',
  styleUrls: ['./noticias-list.page.scss'],
})
export class NoticiasListPage implements OnInit {

  noticias: Noticia[];

  constructor(
    private noticiasService: NoticiasService
  ) { }

  ngOnInit() {
    this.noticiasService.doSelecionarNoticias().subscribe((noticias) => {
      this.noticias = noticias;
    });
  }

  abrirLinkNoticia(link: string) {
    window.open(link, '_system');
  }

}
