import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Usuario } from 'src/models/Usuario';
import { LoginService } from 'src/providers/login/login.service';
import { NavController } from '@ionic/angular';
import { NavDataService } from 'src/providers/nav-data/nav-data.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  loginForm: FormGroup;

  usuario: Usuario;

  constructor(
    private formBuilder: FormBuilder,
    private loginService: LoginService,
    private navController: NavController,
    private navData: NavDataService,
  ) {
    this.loginForm = this.formBuilder.group({
      login: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  ngOnInit() {
  }

  doConfirmar() {
    this.usuario = this.loginForm.getRawValue() as Usuario;

    // alert(JSON.stringify(this.usuario));

    this.loginService.validar(this.usuario).subscribe((result) => {
      if (result) {
        this.navData.data = this.usuario;
        this.navController.navigateRoot('home');
      }
    }, (error) => {
      alert(error);

      this.loginForm.reset();
    });
  }

}
