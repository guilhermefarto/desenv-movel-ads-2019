package br.edu.fema.meusestudosapis.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import br.edu.fema.meusestudosapis.business.EventoBO;
import br.edu.fema.meusestudosapis.models.EventoVO;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@CrossOrigin
@Controller
@RequestMapping("/api/eventos")
public class EventoController {

	// Injeção de dependência
	@Autowired
	private EventoBO eventoBO;

	@ApiOperation("Recupera todos os eventos")
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	@ApiResponses({ @ApiResponse(code = 200, message = "Todos os eventos"),
			@ApiResponse(code = 500, message = "Erro interno"),
			@ApiResponse(code = 404, message = "Evento não encontrado") })
	public ResponseEntity<List<EventoVO>> getEventos() {
		return ResponseEntity.ok(this.eventoBO.getEventos()); // ok = 200
	}

	@ApiOperation("Insere um novo evento")
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<EventoVO> insertEvento(@RequestBody EventoVO evento) {
		EventoVO result = this.eventoBO.insertEvento(evento);

		return ResponseEntity.status(HttpStatus.CREATED).body(result);
	}

	@ApiOperation("Atualiza um evento pelo {codigo}")
	@RequestMapping(value = "/{codigo}", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<EventoVO> updateEvento(@PathVariable("codigo") String codigo, @RequestBody EventoVO evento) {
		evento.setCodigo(codigo);

		EventoVO result = this.eventoBO.updateEvento(evento);

		if (result != null) {
			return ResponseEntity.ok(result);
		}

		return ResponseEntity.notFound().build();
	}

	@ApiOperation("Remove um evento pelo {codigo}")
	@RequestMapping(value = "/{codigo}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<EventoVO> deleteEvento(@PathVariable("codigo") String codigo) {
		EventoVO result = this.eventoBO.deleteEvento(codigo);

		if (result != null) {
			return ResponseEntity.ok(result);
		}

		return ResponseEntity.notFound().build();
	}

}
