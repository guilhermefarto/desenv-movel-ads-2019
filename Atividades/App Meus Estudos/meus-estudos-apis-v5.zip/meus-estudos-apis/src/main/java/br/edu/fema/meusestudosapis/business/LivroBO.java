package br.edu.fema.meusestudosapis.business;

import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;

import br.edu.fema.meusestudosapis.models.LivroVO;
import br.edu.fema.meusestudosapis.repositories.LivroRepository;

@Service
public class LivroBO {

	@Autowired
	private LivroRepository repository;

	public List<LivroVO> getLivros() {
		List<LivroVO> livros = new LinkedList<>();

		this.repository.findAll().forEach(livro -> livros.add(livro));

		return livros;
	}

	public LivroVO insertLivro(LivroVO livro) {
		if (Strings.isNullOrEmpty(livro.getIsbn())) {
			livro.setIsbn(UUID.randomUUID().toString());
		}

		this.repository.save(livro);

		return livro;
	}

	public LivroVO updateLivro(LivroVO livro) {
		if (this.repository.findById(livro.getIsbn()).isPresent()) {
			this.repository.save(livro);

			return livro;
		}

		return null;
	}

	public LivroVO deleteLivro(String codigo) {
		if (this.repository.findById(codigo).isPresent()) {
			LivroVO livro = this.repository.findById(codigo).get();

			this.repository.deleteById(codigo);

			return livro;
		}

		return null;
	}

}
