import { Component, OnInit } from '@angular/core';
import { Noticia } from 'src/models/Noticia';
import { NoticiasService } from 'src/providers/noticias/noticias.service';

@Component({
  selector: 'app-noticias-list',
  templateUrl: './noticias-list.page.html',
  styleUrls: ['./noticias-list.page.scss'],
})
export class NoticiasListPage implements OnInit {

  noticias: Noticia[];

  constructor(
    private noticiasService: NoticiasService
  ) {
    this.noticiasService.consultarNoticias().subscribe((noticias) => {
      this.noticias = noticias;
    });
  }

  ngOnInit() {
  }

  abrirLinkNoticia(link: string) {
    window.open(link, '_system');
  }

}
