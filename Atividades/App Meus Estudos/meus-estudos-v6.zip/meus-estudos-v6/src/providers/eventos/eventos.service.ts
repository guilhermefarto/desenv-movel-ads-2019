import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Evento } from 'src/models/Evento';
import { PreferencesService } from '../prefs/preferences.service';

@Injectable({
  providedIn: 'root'
})
export class EventosService {

  static readonly BASE_URL: string = 'http://10.1.1.3:8090/api/meus-estudos/';

  constructor(
    private preferencesService: PreferencesService,
    private http: HttpClient,
  ) { }

  sincronizarEventos(): Observable<Evento[]> {
    return Observable.create((observer: any) => {
      this.http.get<Evento[]>(EventosService.BASE_URL + 'eventos').subscribe((eventos: Evento[]) => {
        console.log(eventos);

        this.salvarEventos(eventos).subscribe((eventos: Evento[]) => {
          observer.next(eventos);
        });
      });
    });
  }

  salvarEventos(novosEventos: Evento[]): Observable<Evento[]> {
    return Observable.create((observer: any) => {
      this.preferencesService.get('eventos').subscribe((eventos: Evento[]) => {
        if (eventos === undefined || eventos === null) {
          eventos = [];
        }

        if (novosEventos && novosEventos.length > 0) {
          novosEventos.forEach(function (novoEvento: Evento) {
            eventos = eventos.filter(evento => evento.codigo !== novoEvento.codigo);
          });
        }

        eventos = eventos.concat(novosEventos);

        this.preferencesService.save('eventos', eventos).subscribe(() => {
          observer.next(eventos);
        });
      });
    });
  }

  consultarEventos(): Observable<Evento[]> {
    return Observable.create((observer: any) => {
      this.preferencesService.get('eventos').subscribe((eventos: Evento[]) => {
        observer.next(eventos);
      });
    });
  }

  salvarEvento(novoEvento: Evento): Observable<Evento[]> {
    return Observable.create((observer: any) => {
      this.preferencesService.get('eventos').subscribe((eventos: Evento[]) => {
        if (eventos === undefined || eventos === null) {
          eventos = [];
        }

        let eventoIndex = eventos.findIndex(evento => evento.codigo === novoEvento.codigo);

        if (eventoIndex !== -1) {
          eventos[eventoIndex] = novoEvento;
        } else {
          eventos.push(novoEvento);
        }

        this.preferencesService.save('eventos', eventos).subscribe(() => {
          observer.next(eventos);
        });
      });
    });
  }

  removerEvento(codigo: string): Observable<Evento[]> {
    return Observable.create((observer: any) => {
      this.preferencesService.get('eventos').subscribe((eventos: Evento[]) => {
        if (eventos === undefined || eventos === null) {
          eventos = [];
        }

        eventos = eventos.filter(evento => evento.codigo !== codigo);

        this.preferencesService.save('eventos', eventos).subscribe(() => {
          observer.next(eventos);
        });
      });
    });
  }
}
