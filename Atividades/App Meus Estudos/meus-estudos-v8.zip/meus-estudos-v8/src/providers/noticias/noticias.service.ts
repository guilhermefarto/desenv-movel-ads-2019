import { Injectable } from '@angular/core';
import { Noticia } from 'src/models/Noticia';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NoticiasService {

  constructor() { }

  consultarNoticias(): Observable<Noticia[]> {
    return Observable.create((observer: any) => {
      let noticias: Noticia[] = [
        { titulo: 'Alunos aprendem novas metodologias', resumo: 'A palestra “Inovações Disruptivas em Educação e Metodologias Ativas” abordou a quebra de paradigmas do modelo tradicional de ensino e mostrou como funcionam as novas metodologias de EAD híbrido', link: 'https://fema.edu.br/index.php/noticias-pagina/1349-alunos-da-fema-aprendem-novas-metodologias' },
        { titulo: 'Abertas inscrições para curso gratuito', resumo: 'FEMA recebe, de 18 de fevereiro a 7 de março de 2019, inscrições gratuitas para processo seletivo para o curso FEMA Robótica, voltado para alunos de ensino fundamental e médio', link: 'https://fema.edu.br/index.php/noticias-pagina/1347-abertas-inscricoes-para-curso-gratuito-de-robotica' },
        { titulo: 'Fisioterapeuta ministra palestra na FEMA', resumo: 'A palestra "Podoposturologia: a importância das palmilhas posturais”, ministrada pelo fisioterapeuta do Dr. José Otávio Castanha, reuniu mais de 50 estudantes e profissionais da área da saúde', link: 'https://fema.edu.br/index.php/noticias-pagina/1346-alunos-da-fema-assistem-a-palestra-de-podoposturologia' },
      ];

      observer.next(noticias);
    });
  }
}
