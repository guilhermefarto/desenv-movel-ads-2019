import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { Livro } from 'src/models/Livro';
import { LivrosService } from 'src/providers/livros/livros.service';

@Component({
  selector: 'app-livros-list',
  templateUrl: './livros-list.page.html',
  styleUrls: ['./livros-list.page.scss'],
})
export class LivrosListPage implements OnInit {

  livros: Livro[] = [];

  constructor(
    private livrosService: LivrosService,
    private navController: NavController,
  ) { }

  ngOnInit() {
  }

  ionViewWillEnter() {
    this.doLoadLivros();
  }

  doLoadLivros() {
    this.livrosService.consultarLivros().subscribe((livros) => {
      this.livros = livros;
    });
  }

  doRemover(isbn: string) {
    this.livrosService.removerLivro(isbn).subscribe((livros) => {
      this.livros = livros;
    });
  }

  doIncluir() {
    this.navController.navigateForward('livros-create');
  }

  doSincronizar() {
    this.livrosService.sincronizarLivros().subscribe((livros) => {
      this.livros = livros;
    });
  }

}
