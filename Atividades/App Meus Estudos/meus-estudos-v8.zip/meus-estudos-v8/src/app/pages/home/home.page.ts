import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { Usuario } from 'src/models/Usuario';
import { NavDataService } from 'src/providers/nav-data/nav-data.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {

  usuario: Usuario;

  constructor(
    private navController: NavController,
    private navData: NavDataService,
  ) {

    this.usuario = this.navData.data;

  }

  ngOnInit(): void {
  }

  doSair() {
    this.navController.navigateRoot('login');
  }

  doExibirNoticias() {
    this.navController.navigateForward('noticias-list');
  }

  doExibirMeusDados() {
    this.navController.navigateForward('meus-dados');
  }

  doExibirEventos() {
    this.navController.navigateForward('eventos-list');
  }

  doExibirLivros() {
    this.navController.navigateForward('livros-list');
  }

}
