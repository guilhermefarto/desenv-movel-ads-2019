import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NavDataService {

  data: any;

  constructor() { }
}
