export class Usuario {

    login: string;
    password: string;

}