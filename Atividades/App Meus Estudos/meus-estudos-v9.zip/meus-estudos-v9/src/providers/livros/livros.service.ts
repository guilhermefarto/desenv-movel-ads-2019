import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Livro } from 'src/models/Livro';
import { PreferencesService } from '../prefs/preferences.service';

@Injectable({
  providedIn: 'root'
})
export class LivrosService {

  static readonly BASE_URL: string = 'http://localhost:9090/meus-estudos/api/';

  constructor(
    private preferencesService: PreferencesService,
    private http: HttpClient,
  ) { }

  sincronizarLivros(): Observable<Livro[]> {
    return Observable.create((observer: any) => {
      this.http.get<Livro[]>(LivrosService.BASE_URL + 'livros')
        .subscribe((livros: Livro[]) => {
          console.log(livros);

          this.salvarLivros(livros).subscribe((livros: Livro[]) => {
            observer.next(livros);
          });
        });
    });
  }

  salvarLivros(novosLivros: Livro[]): Observable<Livro[]> {
    return Observable.create((observer: any) => {
      this.preferencesService.save('livros', novosLivros).subscribe(() => {
        observer.next(novosLivros);
      });
    });
  }

  consultarLivros(): Observable<Livro[]> {
    return Observable.create((observer: any) => {
      this.preferencesService.get('livros').subscribe((livros: Livro[]) => {
        observer.next(livros);
      });
    });
  }

  salvarLivro(novoLivro: Livro): Observable<Livro[]> {
    return Observable.create((observer: any) => {
      this.http.post<Livro>(LivrosService.BASE_URL + 'livros', novoLivro)
        .subscribe((livroGerado: Livro) => {
          console.log(livroGerado);

          this.sincronizarLivros().subscribe((livros: Livro[]) => {
            observer.next(livros);
          });
        });
    });
  }

  removerLivro(isbn: string): Observable<Livro[]> {
    return Observable.create((observer: any) => {
      this.http.delete<Livro>(LivrosService.BASE_URL + 'livros/' + isbn)
        .subscribe((livroRemovido: Livro) => {
          console.log(livroRemovido);

          this.sincronizarLivros().subscribe((livros: Livro[]) => {
            observer.next(livros);
          });
        });
    });
  }

}
