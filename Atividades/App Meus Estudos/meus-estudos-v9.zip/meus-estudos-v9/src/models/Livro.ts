export class Livro {

    isbn: string;
    titulo: string;
    autor: string;
    quantidadePaginas: number;
    categoria: string;

}
