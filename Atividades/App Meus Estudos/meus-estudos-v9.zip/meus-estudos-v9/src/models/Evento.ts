export class Evento {

    codigo: string;
    titulo: string;
    tipo: string;
    local: string;
    data: string;
    pago: boolean;
}