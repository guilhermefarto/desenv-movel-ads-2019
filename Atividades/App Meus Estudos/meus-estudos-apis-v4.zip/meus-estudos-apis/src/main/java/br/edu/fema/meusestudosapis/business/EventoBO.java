package br.edu.fema.meusestudosapis.business;

import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.edu.fema.meusestudosapis.models.EventoVO;
import br.edu.fema.meusestudosapis.repositories.EventoRepository;

@Service
public class EventoBO {

	@Autowired
	private EventoRepository repository;

	public List<EventoVO> getEventos() {
		List<EventoVO> eventos = new LinkedList<>();

		this.repository.findAll().forEach(evento -> eventos.add(evento));

		return eventos;
	}

	public EventoVO insertEvento(EventoVO evento) {
		evento.setCodigo(UUID.randomUUID().toString());

		this.repository.save(evento);

		return evento;
	}

	public EventoVO updateEvento(EventoVO evento) {
		if (this.repository.findById(evento.getCodigo()).isPresent()) {
			this.repository.save(evento);

			return evento;
		}

		return null;
	}

	public EventoVO deleteEvento(String codigo) {
		if (this.repository.findById(codigo).isPresent()) {
			EventoVO evento = this.repository.findById(codigo).get();

			this.repository.deleteById(codigo);

			return evento;
		}

		return null;
	}
	
}
