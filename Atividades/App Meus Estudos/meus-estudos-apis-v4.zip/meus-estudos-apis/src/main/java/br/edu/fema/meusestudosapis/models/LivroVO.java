package br.edu.fema.meusestudosapis.models;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "Livro", description = "Representa uma entidade de livro")
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Entity
@Table(name = "livros")
public class LivroVO {

	@ApiModelProperty(value = "ISBN do livro")
	@Id
	private String isbn;

	@ApiModelProperty(value = "Título do livro")
	private String titulo;

	@ApiModelProperty(value = "Autor do livro")
	private String autor;

	@ApiModelProperty(value = "Quantidade páginas do livro")
	private int quantidadePaginas;

	@ApiModelProperty(value = "Categoria do livro")
	private String categoria;

}
