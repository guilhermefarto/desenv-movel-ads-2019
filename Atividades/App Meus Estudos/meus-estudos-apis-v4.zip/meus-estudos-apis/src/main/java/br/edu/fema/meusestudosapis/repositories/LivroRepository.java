package br.edu.fema.meusestudosapis.repositories;

import org.springframework.data.repository.PagingAndSortingRepository;

import br.edu.fema.meusestudosapis.models.LivroVO;

public interface LivroRepository extends PagingAndSortingRepository<LivroVO, String> {
}