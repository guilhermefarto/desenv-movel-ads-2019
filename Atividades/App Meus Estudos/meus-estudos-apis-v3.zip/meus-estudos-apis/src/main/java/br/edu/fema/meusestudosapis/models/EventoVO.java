package br.edu.fema.meusestudosapis.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "Evento", description = "Representa uma entidade de evento")
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Entity
@Table(name = "eventos")
public class EventoVO {

	@ApiModelProperty(value = "Código do evento")
	@Id
	// @Column(name = "CD", length = 50, nullable = false, unique = true)
	private String codigo;

	@ApiModelProperty(value = "Título do evento")
	private String titulo;

	@ApiModelProperty(value = "Tipo do evento")
	private String tipo;

	@ApiModelProperty(value = "Local do evento")
	private String local;

	@ApiModelProperty(value = "Data do evento")
	private String data;

	@ApiModelProperty(value = "Categoria do evento (pago ou gratuito)")
	private boolean pago;
	
}
