import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { Usuario } from 'src/models/Usuario';
import { PreferencesService } from 'src/providers/prefs/preferences.service';

@Component({
  selector: 'app-meus-dados',
  templateUrl: './meus-dados.page.html',
  styleUrls: ['./meus-dados.page.scss'],
})
export class MeusDadosPage implements OnInit {

  meusDadosForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private navController: NavController,
    private preferencesService: PreferencesService,
  ) {
    this.meusDadosForm = this.formBuilder.group({
      login: ['', Validators.required],
      name: ['', Validators.required],
      email: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  ngOnInit() {
    this.preferencesService.get('logged-user').subscribe((data: Usuario) => {
      if (data) {
        this.preferencesService.get('users').subscribe((users: Usuario[]) => {
          if (users !== undefined && users !== null) {
            let userIndex = users.findIndex(user => user.login === data.login);

            if (userIndex !== -1) {
              data = users[userIndex];
            }
          }

          this.meusDadosForm.patchValue(data);
        });
      }
    });
  }

  doSalvar() {
    let userData = this.meusDadosForm.getRawValue() as Usuario;

    console.log(userData);

    this.preferencesService.get('users').subscribe((users: Usuario[]) => {
      if (users === undefined || users === null) {
        users = [];
      }

      let userIndex = users.findIndex(user => user.login === userData.login);

      if (userIndex !== -1) {
        users[userIndex] = userData
      } else {
        users.push(userData);
      }

      this.preferencesService.save('users', users).subscribe(() => {
        this.navController.navigateBack('home');
      });
    });
  }

}
