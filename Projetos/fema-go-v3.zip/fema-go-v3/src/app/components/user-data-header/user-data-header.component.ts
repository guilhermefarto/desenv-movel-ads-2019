import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UserCredential } from 'src/models/UserCredentials';

@Component({
  selector: 'app-user-data-header',
  templateUrl: './user-data-header.component.html',
  styleUrls: ['./user-data-header.component.scss']
})
export class UserDataHeaderComponent implements OnInit {

  @Input('loggedUser') loggedUser: UserCredential;

  @Output('onUserDetail') onUserDetail: EventEmitter<any> = new EventEmitter();

  constructor() { }

  ngOnInit() { }

  doClick(): void {
    if (this.onUserDetail) {
      this.onUserDetail.emit(this.loggedUser);
    }
  }
}
