import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { UserDataCardComponent } from './user-data-card/user-data-card.component';
import { UserDataHeaderComponent } from './user-data-header/user-data-header.component';

@NgModule({
    declarations: [UserDataCardComponent, UserDataHeaderComponent],
    exports: [UserDataCardComponent, UserDataHeaderComponent],
    imports: [CommonModule, IonicModule],
})
export class ComponentsModule { }