import { Component, Input, OnInit } from '@angular/core';
import { UserCredential } from 'src/models/UserCredentials';

@Component({
  selector: 'app-user-data-card',
  templateUrl: './user-data-card.component.html',
  styleUrls: ['./user-data-card.component.scss']
})
export class UserDataCardComponent implements OnInit {

  @Input('loggedUser') loggedUser: UserCredential;

  isExpanded: boolean = false;

  constructor() { }

  ngOnInit() { }

  doClick(data): void {
    this.isExpanded = !this.isExpanded;
  }
}
