import { Component } from '@angular/core';
import { UserCredential } from 'src/models/UserCredentials';
import { LoginService } from 'src/providers/login/login.service';
import { UserSessionService } from 'src/providers/user-session/user-session.service';
import { AlertDialogService } from 'src/shared/providers/alert-dialog/alert-dialog.service';
import { AlertNotificationOptions } from 'src/shared/providers/alert-notification/alert-notification.opts';
import { AlertNotificationService } from 'src/shared/providers/alert-notification/alert-notification.service';
import { NavDataService } from 'src/shared/providers/nav-data/nav-data.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  loggedUser: UserCredential;
  notificationCount: number = 16;

  constructor(
    private navData: NavDataService,
    private userSessionService: UserSessionService,
    private loginService: LoginService,
    private alertDialog: AlertDialogService,
    private alertNotification: AlertNotificationService,
  ) { }

  ngOnInit(): void {
    // this.loggedUser = this.navData.dataParams['userCredentials'];
    this.userSessionService.getLoggedUser().subscribe((user) => {
      this.loggedUser = user;
    });
  }

  doLogout() {
    this.alertDialog.presentAlert(() => {
      this.loginService.doLogout().subscribe(() => {
        this.navData.navigateRoot('login');
      });
    });
  }

  doShowNotifications() {
    alert(`Você possui ${this.notificationCount} aviso(s)`);
  }

  doUserDetail(loggedUser: UserCredential) {
    alert(`Você clicou em ${loggedUser.name}`);
  }

  doRefresh(event) {
    setTimeout(() => {
      event.target.complete();

      this.alertNotification.show('Dados atualizados com sucesso...', new AlertNotificationOptions({ type: 'success' }));
    }, 2000);
  }
}
