import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserCredential } from 'src/models/UserCredentials';
import { LoginService } from 'src/providers/login/login.service';
import { AlertNotificationOptions } from 'src/shared/providers/alert-notification/alert-notification.opts';
import { AlertNotificationService } from 'src/shared/providers/alert-notification/alert-notification.service';
import { NavDataService } from 'src/shared/providers/nav-data/nav-data.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  loginForm: FormGroup;

  userCredentials: UserCredential;

  constructor(
    private formBuilder: FormBuilder,
    private navData: NavDataService,
    private loginService: LoginService,
    private alertNotification: AlertNotificationService,
  ) {

    this.loginForm = this.formBuilder.group({
      login: ['', Validators.required],
      password: ['', Validators.required],
      rememberUser: [false],
    });

  }

  ngOnInit() {
    // this.loadDefaultValues();
  }

  loadDefaultValues() {
    this.loginForm.get('login').setValue('guilherme.farto');
    this.loginForm.get('password').setValue('1234');
  }

  doLogin() {
    this.userCredentials = this.loginForm.getRawValue() as UserCredential;

    this.loginService.doLogin(this.userCredentials).subscribe((data) => {
      this.navData.navigateRoot('home', {
        userCredentials: data
      });
    }, (error) => {
      this.alertNotification.show(error, new AlertNotificationOptions({ type: 'danger' }));

      this.loginForm.reset({
        rememberUser: false
      });
    });
  }

  doRegister() {
  }
}
