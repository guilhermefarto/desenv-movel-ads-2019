import { Component } from '@angular/core';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Platform } from '@ionic/angular';
import { UserSessionService } from 'src/providers/user-session/user-session.service';
import { NavDataService } from 'src/shared/providers/nav-data/nav-data.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html'
})
export class AppComponent {
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private userSessionService: UserSessionService,
    private navData: NavDataService,
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();

      this.userSessionService.hasLoggedUser().subscribe((value) => {
        if (value) {
          this.userSessionService.getLoggedUser().subscribe((loggedUser) => {
            if (loggedUser.rememberUser) {
              this.navData.navigateRoot('home', {
                userCredentials: loggedUser
              });
            }
          });
        }
      });
    });
  }
}
