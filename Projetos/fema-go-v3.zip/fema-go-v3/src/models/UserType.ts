export enum UserType {

    STUDENT, TEACHER, EMPLOYEE

}