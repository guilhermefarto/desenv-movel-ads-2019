import { UserType } from './UserType';

export class UserCredential {

    login: string;
    name: string;
    password: string;
    rememberUser: boolean;
    userType: UserType;

    constructor(data?: any) {
        Object.assign(this, data);
    }

}