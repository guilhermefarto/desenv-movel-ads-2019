import { Injectable } from '@angular/core';
import { AlertController } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class AlertDialogService {

  constructor(public alertController: AlertController) { }

  async presentAlert(callback?) {
    const alert = await this.alertController.create({
      header: 'Logout',
      // subHeader: '',
      message: 'Deseja sair da aplicação?',
      buttons: ['NÃO', {
        text: 'SIM',
        handler: () => {
          callback();
        }
      }]
    });

    return await alert.present();
  }
}
