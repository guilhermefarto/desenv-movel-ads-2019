export class AlertNotificationOptions {

    type: string = 'primary';

    constructor(data?: any) {
        Object.assign(this, data);
    }

    getCssClass(): string {
        return 'toast-' + this.type;
    }
}