import { Injectable } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { AlertNotificationOptions } from './alert-notification.opts';

@Injectable({
  providedIn: 'root'
})
export class AlertNotificationService {

  constructor(
    private toastController: ToastController) { }

  // https://forum.ionicframework.com/t/how-to-add-toast-action-button/61377/8

  async show(message: string, opts?: AlertNotificationOptions) {
    const toast = await this.toastController.create({
      message: message,
      duration: 5000,
      position: 'bottom', // top
      showCloseButton: true,
      closeButtonText: 'OK',
      // color: opts.type,
      cssClass: opts ? opts.getCssClass() : 'toast-primary',
    });

    toast.onDidDismiss().then(() => {
      console.log('Toast dismissed...');
    });

    toast.present();
  }
}
