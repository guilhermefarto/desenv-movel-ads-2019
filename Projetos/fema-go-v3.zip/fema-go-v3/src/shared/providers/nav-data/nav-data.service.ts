import { Injectable } from '@angular/core';
import { NavController } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class NavDataService {

  dataParams: any;

  constructor(private nav: NavController) { }

  navigateBack(url: string, extras?: any): any {
    this.dataParams = {};

    Object.assign(this.dataParams, extras);

    this.nav.navigateBack(url);
  }

  navigateForward(url: string, extras?: any): any {
    this.dataParams = {};

    Object.assign(this.dataParams, extras);

    this.nav.navigateForward(url);
  }

  navigateRoot(url: string, extras?: any): any {
    this.dataParams = {};

    Object.assign(this.dataParams, extras);

    this.nav.navigateRoot(url, { animated: true, animationDirection: 'forward' });
  }

  get(key: string): any {
    return this.dataParams[key];
  }
}
