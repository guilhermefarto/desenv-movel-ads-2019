import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UserCredential } from 'src/models/UserCredentials';
import { UserSessionService } from '../user-session/user-session.service';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private users: UserCredential[] = [
    new UserCredential({ login: 'guilherme.farto', name: 'Guilherme de Cleva Farto', password: '1' }),
    new UserCredential({ login: 'aluno1', name: 'Aluno 1', password: '2' }),
    new UserCredential({ login: 'aluno2', name: 'Aluno 2', password: '3' }),
  ];

  constructor(
    private userSessionService: UserSessionService,
  ) { }

  doLogin(user: UserCredential): Observable<UserCredential> {
    return Observable.create((observer: any) => {
      let userFound = this.users.find((item) => item.login === user.login);

      if (userFound && userFound.password === user.password) {
        userFound.rememberUser = user.rememberUser;

        this.userSessionService.saveLoggedUser(userFound).subscribe((data) => {
          observer.next(userFound);
        });
      } else {
        observer.error('Usuário ou senha inválidos');
      }
    });
  }

  doLogout(): Observable<boolean> {
    return Observable.create((observer: any) => {
      this.userSessionService.removeLoggedUser().subscribe(() => {
        observer.next(true);
      });
    });
  }
}
