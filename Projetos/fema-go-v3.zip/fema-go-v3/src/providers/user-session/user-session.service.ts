import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { UserCredential } from 'src/models/UserCredentials';

@Injectable({
  providedIn: 'root'
})
export class UserSessionService {

  constructor(
    private storage: Storage
  ) { }

  saveLoggedUser(user: UserCredential): Observable<UserCredential> {
    return this.save('loggedUser', user);
  }

  save(key: string, value: any): Observable<UserCredential> {
    return Observable.create((observer: any) => {
      this.storage.set(key, value).then((data) => {
        observer.next(value);
      });
    });
  }

  hasLoggedUser(): Observable<boolean> {
    return this.getLoggedUser().pipe(
      map((data) => {
        return data !== undefined && data !== null;
      })
    );
  }

  getLoggedUser(): Observable<UserCredential> {
    return this.get('loggedUser');
  }

  get(key: string): Observable<any> {
    return Observable.create((observer: any) => {
      this.storage.get(key).then((data) => {
        observer.next(data);
      });
    });
  }

  removeLoggedUser(): Observable<UserCredential> {
    return this.remove('loggedUser');
  }

  remove(key: string): Observable<UserCredential> {
    return Observable.create((observer: any) => {
      this.storage.remove(key).then((data) => {
        let loggedUser: UserCredential = data;

        observer.next(loggedUser);
      });
    });
  }

  clear(): Observable<any> {
    return Observable.create((observer: any) => {
      this.storage.clear().then(() => {
        observer.next();
      });
    });
  }

  keys(): Observable<Array<string>> {
    return Observable.create((observer: any) => {
      this.storage.keys().then((data) => {
        observer.next(data);
      });
    });
  }
}
