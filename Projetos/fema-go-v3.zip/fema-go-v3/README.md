
# Criar projeto

Abrir VS Code

terminal > cd C:\desenvmovel\workspace

terminal > ionic start fema-go blank

terminal > cd .\fema-go\

Abrir diretório '.\fema-go\' no VS Code (menu 'File' > 'Open folder...')

## Executar a aplicação (Ionic Lab)

terminal > ionic serve --lab

Abrir browser e navegar: http://localhost:8200/

# Desenvolvimento (versão 2)

Criar diretório 'models' (para armazenar classes, interfaces, enumerações, ...)

## Gerar página de login

terminal > ionic generate page pages/login

## Gerar serviço/provedor de login

terminal > ionic generate service ../providers/login/login

## Gerar serviço/provedor de navegação (envio e recebimento de dados entre páginas)

terminal > ionic generate service ../shared/providers/nav-data/nav-data

## Gerar serviço/provedor de janelas (toast) de notificações e alertas

terminal > ionic generate service ../shared/providers/alert-notification/alert-notification

## Gerar serviço/provedor de janelas (dialogs) de notificações e alertas

terminal > ionic generate service ../shared/providers/alert-dialog/alert-dialog

## Executar a aplicação (Ionic Lab)

terminal > ionic serve --lab

Abrir browser e navegar: http://localhost:8200/

## Consulta e download de ícones

https://ionicons.com/

# Desenvolvimento (versão 3)

## Criar serviço/provedor de sessão (para armazenar dados e preferências do usuário logado)

terminal > npm install --save @ionic/storage

Adicionar o módulo 'IonicStorageModule' na área de imports do arquivo 'app.module.ts'

    IonicStorageModule.forRoot({
      name: 'fema-go-db',
      storeName: 'preferences',
      driverOrder: ['indexeddb', 'sqlite', 'websql']
    }),

terminal > ionic generate service ../providers/user-session/user-session

Implementar classe 'UserSessionService'

## Implementar login automático (quando usuário logado está salvo)

Implementar desvio condicional no arquivo 'app.component.ts'

    this.userSessionService.hasLoggedUser().subscribe((value) => {
      if (value) {
        this.userSessionService.getLoggedUser().subscribe((loggedUser) => {
          if (loggedUser.rememberUser) {
              this.navData.navigateRoot('home', {
              userCredentials: loggedUser
              });
          }
        });
      }
    });

## Implementar componente customizado (para card de cabeçalho na tela principal)

terminal > ionic generate component components/user-data-header

## Implementar componente customizado (para card de informações do usuário logado)

terminal > ionic generate component components/user-data-card

### Criar módulo 'ComponentsModule' na raíz do diretório 'components'

    import { NgModule } from '@angular/core';
    import { IonicModule } from '@ionic/angular';
    import { UserDataCardComponent } from './user-data-card/user-data-card.component';

    @NgModule({
        declarations: [UserDataCardComponent, UserDataHeaderComponent],
        exports: [UserDataCardComponent, UserDataHeaderComponent],
        imports: [CommonModule, IonicModule],
    })
    export class ComponentsModule { }

### Adicionar dependência de módulo 'ComponentsModule' no módulo da página Home ('HomePageModule')

    @NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        IonicModule,
        ComponentsModule,
        RouterModule.forChild([
        {
            path: '',
            component: HomePage
        }
        ])
    ],
    declarations: [HomePage]
    })
    export class HomePageModule { }

## Implementar funcionalidade de 'refresher' (recurso de puxar-arrastar para atualizar página) - arquivo 'home.page.html'

    <ion-content padding>
      <ion-refresher slot="fixed" (ionRefresh)="doRefresh($event)">
        <ion-refresher-content pullingIcon="refresh" refreshingSpinner="circles">
        </ion-refresher-content>
      </ion-refresher>
      <app-user-data-card [loggedUser]="loggedUser"></app-user-data-card>
    </ion-content>

##