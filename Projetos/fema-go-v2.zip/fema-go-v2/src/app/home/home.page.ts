import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { UserCredential } from 'src/models/UserCredentials';
import { NavDataService } from 'src/shared/providers/nav-data/nav-data.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  loggedUser: UserCredential;

  constructor(
    private navData: NavDataService,
    private nav: NavController) {
  }

  ngOnInit(): void {
    this.loggedUser = this.navData.dataParams;
  }

  doLogout() {
    this.nav.navigateRoot('login');
  }
}
