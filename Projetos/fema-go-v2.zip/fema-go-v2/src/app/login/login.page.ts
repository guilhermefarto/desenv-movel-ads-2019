import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { UserCredential } from 'src/models/UserCredentials';
import { LoginService } from 'src/providers/login/login.service';
import { AlertNotificationService } from 'src/shared/providers/alert-notification/alert-notification.service';
import { NavDataService } from 'src/shared/providers/nav-data/nav-data.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  loginForm: FormGroup;

  userCredentials: UserCredential = { login: 'guilherme.farto', password: 'totvs', rememberUser: true };

  constructor(
    private formBuilder: FormBuilder,
    private alertNotification: AlertNotificationService,
    private loginService: LoginService,
    private navData: NavDataService,
    private nav: NavController) {

    this.loginForm = this.formBuilder.group({
      login: ['', Validators.required],
      password: ['', Validators.required],
      rememberUser: [true],
    });

  }

  ngOnInit() {
    // this.loadDefaultValues();
  }

  loadDefaultValues() {
    this.loginForm.get('login').setValue('fema.aluno');
    this.loginForm.get('password').setValue('123');
  }

  doLogin() {
    this.userCredentials = this.loginForm.getRawValue() as UserCredential;

    this.loginService.doLogin(this.userCredentials).subscribe((data) => {
      this.navData.dataParams = this.userCredentials;
      this.nav.navigateRoot('home');
    }, (error) => {
      this.alertNotification.show(error);

      this.loginForm.reset({
        rememberUser: true
      });
    });
  }

  doRegister() {
  }
}
