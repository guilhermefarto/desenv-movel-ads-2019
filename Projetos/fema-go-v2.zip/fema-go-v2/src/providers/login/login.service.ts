import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UserCredential } from 'src/models/UserCredentials';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor() { }

  doLogin(user: UserCredential): Observable<UserCredential> {
    return Observable.create((observer: any) => {
      // if (user.login === 'fema.aluno' && user.password === '123') {
      if (user.password === '123') {
        observer.next(user);
      } else {
        observer.error('Usuário ou senha inválidos');
      }
    });
  }
}
