export class UserCredential {

    login: string;
    password: string;
    rememberUser: boolean;

}